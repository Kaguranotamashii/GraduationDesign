
// src/component/AuthTest.js
import React, { useState, useEffect } from 'react';
import { message, Input, Button, Form } from 'antd'; // 引入 Ant Design 的组件
import { getUserList, addRandomUser, loginUser, registerUser, logoutUser } from '../api/user'; // 引入用户相关的 API

const AuthTest = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [loginForm] = Form.useForm();
    const [registerForm] = Form.useForm();



    // 登录用户
    const handleLogin = async (values) => {
        try {
            const response = await loginUser(values);
            message.success('登录成功');
            console.log('登录成功:', response);
        } catch (error) {
            message.error('登录失败: ' + error.message);
        }
    };

    // 注册用户
    const handleRegister = async (values) => {
        try {
            const response = await registerUser(values);
            message.success('注册成功');
            console.log('注册成功:', response);
        } catch (error) {
            message.error('注册失败: ' + error.message);
        }
    };

    // 登出用户
    const handleLogout = async () => {
        try {
            const response = await logoutUser();
            message.success('登出成功');
            console.log('登出成功:', response);
        } catch (error) {
            message.error('登出失败: ' + error.message);
        }
    };



    return (
        <div>
            <h1>用户管理测试</h1>

            {/* 登录表单 */}
            <Form form={loginForm} onFinish={handleLogin} layout="inline">
                <Form.Item name="username" label="用户名" rules={[{ required: true, message: '请输入用户名' }]}>
                    <Input />
                </Form.Item>
                <Form.Item name="password" label="密码" rules={[{ required: true, message: '请输入密码' }]}>
                    <Input.Password />
                </Form.Item>
                <Form.Item>
                    <Button type="primary" htmlType="submit">登录</Button>
                </Form.Item>
            </Form>

            {/* 注册表单 */}
            <Form form={registerForm} onFinish={handleRegister} layout="inline">
                <Form.Item name="username" label="用户名" rules={[{ required: true, message: '请输入用户名' }]}>
                    <Input />
                </Form.Item>
                <Form.Item name="password" label="密码" rules={[{ required: true, message: '请输入密码' }]}>
                    <Input.Password />
                </Form.Item>

                <Form.Item>
                    <Button type="primary" htmlType="submit">注册</Button>
                </Form.Item>
            </Form>

            {/* 登出按钮 */}
            <Button onClick={handleLogout}>登出</Button>




        </div>
    );
};

export default AuthTest;