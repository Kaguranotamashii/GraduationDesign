import axios from 'axios';
import { message } from 'antd'; // Ant Design 的消息组件

// 创建 Axios 实例
const apiClient = axios.create({
    baseURL: 'http://localhost:8005/app', // 后端接口地址
    timeout: 10000,
    withCredentials: true,
});

// 请求拦截器
apiClient.interceptors.request.use(
    (config) => {
        // 在请求头中可以添加 Token 或其他信息（如果需要）
        // config.headers.Authorization = `Bearer ${yourToken}`;
        return config;
    },
    (error) => {
        // 请求错误
        message.error('Request error');
        return Promise.reject(error);
    }
);

// // 响应拦截器
apiClient.interceptors.response.use(
    (response) => {
        const { code, message: msg, data } = response.data;

        if (code === 0) {
            // 如果状态码是成功，直接返回数据
            return data;
        } else {
            // 如果状态码是错误，显示错误提示
            message.error(msg || 'An unknown error occurred');
            return Promise.reject(new Error(msg || 'An unknown error occurred'));
        }
    },
    (error) => {
        // 网络错误或其他错误
        message.error('Network error, please try again later.');
        return Promise.reject(error);
    }
);

export default apiClient;
