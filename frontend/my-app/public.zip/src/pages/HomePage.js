// src/pages/HomePage.js
import React from 'react';
import WeatherModel from "../component/WeatherModel";
import ARApp from "./ARApp";
import UserList from "../component/UserList";
import AuthTest from "../component/UserList";

const HomePage = () => {
    return (
        <div>

            {/*<WeatherModel />*/}
            {/*<ARApp />*/}
            <AuthTest />




        </div>


    );
};

export default HomePage;
