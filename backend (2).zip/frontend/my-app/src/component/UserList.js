import React, { useState, useEffect } from 'react';
import { getUserList } from '../api/user'; // 引入请求函数

const UserList = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        // 调用抽离的请求函数获取用户数据
        const fetchUsers = async () => {
            try {
                const data = await getUserList(); // 调用封装好的函数
                setUsers(data);
            } catch (err) {
                setError('Failed to fetch user data. Please try again later.');
            } finally {
                setLoading(false);
            }
        };

        fetchUsers();
    }, []);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>{error}</div>;
    }

    if (users.length === 0) {
        return <div>No users found.</div>;
    }

    return (
        <div>
            <h2>User List</h2>
            <ul>
                {users.map(user => (
                    <li key={user.id}>
                        <strong>Username:</strong> {user.username} <br />
                        <strong>Register Time:</strong> {new Date(user.register_time).toLocaleString()} <br />
                        <strong>Signature:</strong> {user.signature || 'No signature'}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default UserList;
