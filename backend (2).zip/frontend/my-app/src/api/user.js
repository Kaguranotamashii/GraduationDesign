import axios from 'axios';

// 设置 axios 的默认配置
const instance = axios.create({
    baseURL: 'http://localhost:8005/app/user', // 后端接口的基础路径
    timeout: 5000, // 设置超时时间
});

// 获取用户列表的函数
export const getUserList = async () => {
    try {
        const response = await instance.get('/list/'); // 调用后端接口
        return response.data; // 返回数据
    } catch (error) {
        console.error('Error fetching user list:', error);
        throw error; // 抛出错误供调用方处理
    }
};

// 其他用户相关请求函数可以继续添加，比如创建用户、删除用户等
// export const createUser = async (userData) => { ... }
// export const deleteUser = async (userId) => { ... }
