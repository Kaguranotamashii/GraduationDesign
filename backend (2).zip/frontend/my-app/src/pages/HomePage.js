// src/pages/HomePage.js
import React from 'react';
import WeatherModel from "../component/WeatherModel";
import ARApp from "./ARApp";
import UserList from "../component/UserList";

const HomePage = () => {
    return (
        <div>

            {/*<WeatherModel />*/}
            {/*<ARApp />*/}
            <UserList />




        </div>


    );
};

export default HomePage;
