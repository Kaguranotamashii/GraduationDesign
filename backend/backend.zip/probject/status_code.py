# 状态码定义
SUCCESS = 200
ERROR = 500
INVALID_PARAMS = 400
UNAUTHORIZED = 401
FORBIDDEN = 403

# 状态消息映射
STATUS_MESSAGES = {
    SUCCESS: '请求成功',
    ERROR: '服务器错误',
    INVALID_PARAMS: '参数错误',
    FORBIDDEN: "禁止访问",
    UNAUTHORIZED: "未授权访问",
}