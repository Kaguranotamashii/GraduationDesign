from django.urls import path
from .views import add_random_user, list_users

urlpatterns = [
    path('add-random/', add_random_user, name='add_random_user'),  # 随机添加用户
    path('list/', list_users, name='list_users'),  # 查询所有用户
]
