from django.http import JsonResponse
from .models import User
from faker import Faker  # 使用 Faker 生成随机数据

faker = Faker()


def add_random_user(request):
    """
    随机生成一个用户并存储到数据库中
    """
    username = faker.user_name()
    password = faker.password()
    signature = faker.sentence()

    user = User.objects.create(
        username=username,
        password=password,
        signature=signature
    )
    return JsonResponse({
        'message': 'Random user added successfully',
        'user': {
            'id': user.id,
            'username': user.username,
            'register_time': user.register_time,
            'signature': user.signature
        }
    })


def list_users(request):
    """
    查询所有用户并返回列表
    """
    users = User.objects.all()
    data = [
        {
            'id': user.id,
            'username': user.username,
            'register_time': user.register_time,
            'signature': user.signature
        }
        for user in users
    ]
    return JsonResponse(data, safe=False)
