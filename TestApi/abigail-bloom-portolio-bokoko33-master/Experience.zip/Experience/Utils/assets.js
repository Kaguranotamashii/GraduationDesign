export default [
    {
        name: "room",
        type: "glbModel",
        path: "/models/Finale Version 16.glb",
    },
    {
        name: "screen",
        type: "videoTexture",
        path: "/textures/kda.mp4",
    },
];
